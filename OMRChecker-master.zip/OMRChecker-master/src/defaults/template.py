TEMPLATE_DEFAULTS = {
    "preProcessors": [],
    "emptyValue": "",
    "customLabels": {},
    "outputColumns": [],
}
